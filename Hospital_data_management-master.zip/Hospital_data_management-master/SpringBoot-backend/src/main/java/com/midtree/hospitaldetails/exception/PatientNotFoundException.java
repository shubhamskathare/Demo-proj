package com.midtree.hospitaldetails.exception;

public class PatientNotFoundException  extends RuntimeException{
    public PatientNotFoundException(String string) {
        super();
    }
}
