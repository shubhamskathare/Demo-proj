# Hospital_data_management
Full stack web application with frontend built with Angular framework and backend with SpringBoot framework.

This project was built while doing JAVA fullstack web development internship.



Requirements of the project were:



In a Hospital there are many doctors are appointed. Doctors can be categorized based on their specialist. Each doctor has id , name , age , gender and specialist fields. Patients can be allowed to visit doctor for consultation. Each patient has properties like id, name , visitedDoctor, dateOfVisit. Develop the below functionalities based on the above scenarios. 

1.	Create doctor information. 
2.	Crate patient information . In patient creation page there should be one dropdown box where user needs to select a doctor name from the dropdown box. 
3.	Crate a tab for ShowDoctorInformation. Once user clicks on the showDoctorInformation page a new page will display where there is one dropdown box named as selectDoctor. Once User clicks on and select a doctor name from the dropdown box , it will display the doctor’s information as table in the same page. It show doctorname, specializationfiled and numberOfpatientAttneded. 
4.	In show patient information tab once the user enter patient ID in a text box it will display the patient data like patient name, age, visitedDoctorName, dataOfVist and also the doctor’s prescription. If there is no patient ID in the database then it will display an error page “ No such patient there in the database. 

