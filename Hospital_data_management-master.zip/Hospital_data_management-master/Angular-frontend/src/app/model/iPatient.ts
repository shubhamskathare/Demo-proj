export interface IPatient{
    id?:number;
    doctor_name?:string;
    date_of_visit?:Date;
    prescription?:string;
    age?:number;
    gender?:string;
    name?:string;
}